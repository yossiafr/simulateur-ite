# Simulateur d'autofinancement ITE

Mini-CRM pour les commerciaux en isolation thermique par l'extérieur. On saisit le client, son logement et sa facture de chauffage. L'appli calcule la mensualité du crédit, les économies, les aides (CEE, aide région), la plus-value estimée et le pourcentage du projet couvert. Elle produit une synthèse imprimable et un e-mail mis en page pour le client.

Technique : page web unique (`public/index.html`), base et connexions Supabase, hébergement Vercel avec trois petites fonctions serveur dans `api/`.

## Règles de calcul

1. **Mensualité** : crédit à mensualités constantes sur le montant des travaux, au taux annuel saisi (6 % par défaut). Les intérêts du différé (6 mois par défaut) s'ajoutent au capital. La mensualité peut être saisie à la main.
2. **Économie mensuelle** : facture de chauffage annuelle × taux d'économie (25 % par défaut) ÷ 12, ou saisie à la main.
3. **Économie globale** : économie mensuelle × (différé + durée), avec une hausse annuelle de l'énergie facultative.
4. **Plus-value** : valeur du bien × 10 % (Notaires de France, transactions 2024), réalisable à la revente.
5. **Projet couvert** : (économies + CEE + aide région + plus-value) ÷ total remboursé, affiché jusqu'à 100 %. La part « économies + aides » est affichée à part.

Les valeurs par défaut se règlent dans l'onglet Administration.

## Droits

| | Commercial | Admin |
|---|---|---|
| Voir et modifier ses propres clients | oui | oui |
| Voir et modifier les clients des autres | non | oui |
| Réattribuer une fiche à un autre commercial | non | oui |
| Supprimer une fiche | non | oui |
| Créer, désactiver des comptes, changer un mot de passe | non | oui |
| Modifier les réglages par défaut | non | oui |

Ces droits sont appliqués par la base elle-même (Row Level Security), pas seulement par l'écran.

## Mise en ligne (environ 20 minutes)

1. **Supabase** (supabase.com, offre gratuite) : créer un nouveau projet, région Europe (Paris ou Francfort).
   - SQL Editor › New query : coller le contenu de `supabase/schema.sql`, puis Run.
   - Authentication › Sign In / Providers : désactiver « Allow new users to sign up ».
   - Authentication › Users › Add user › Create new user : votre e-mail et un mot de passe, cocher « Auto Confirm User ». **Ce premier compte devient administrateur.**
   - Project Settings › API : noter l'URL du projet, la clé `anon` et la clé `service_role`.
2. **GitHub** : créer un dépôt privé vide (par exemple `simulateur-ite`) et y envoyer ce code.
3. **Vercel** (vercel.com) : Add New › Project › importer le dépôt GitHub. Framework Preset : **Other**. Dans Environment Variables, renseigner :
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (secrète)

   puis Deploy.
4. **Retour dans Supabase** › Authentication › URL Configuration : mettre l'adresse du site Vercel (par exemple `https://simulateur-ite.vercel.app`) dans « Site URL ». C'est l'adresse du lien « mot de passe oublié ».
5. Se connecter avec le compte administrateur, vérifier les réglages par défaut (onglet Administration), puis créer les comptes des commerciaux.

## Envoi direct des e-mails (facultatif)

Sans réglage, le bouton « Envoyer par e-mail » copie le récapitulatif mis en page et ouvre votre messagerie : il reste à coller et envoyer. Pour que le site envoie l'e-mail lui-même, ajoutez dans Vercel › Settings › Environment Variables :

| Key | Value (exemple Gmail) |
| --- | --- |
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `465` |
| `SMTP_USER` | votre adresse Gmail |
| `SMTP_PASS` | un **mot de passe d'application** Google (myaccount.google.com › Sécurité › Validation en deux étapes › Mots de passe des applications) |

Puis redéployez (Deployments › ⋯ › Redeploy). Les réponses du client arrivent à l'e-mail du commercial connecté. Fonctionne aussi avec Outlook, OVH, Brevo… (mêmes 4 réglages, fournis par la messagerie).

## Lien depuis le site Webflow

Le plus simple est un bouton ou un lien « Espace commerciaux » qui pointe vers l'adresse Vercel. Dans Webflow : sélectionner le bouton › Link Settings › URL, coller l'adresse, cocher « Open in new tab ».

Pour une adresse à votre nom (par exemple `simulateur.votre-site.fr`) : Vercel › Project › Settings › Domains › Add, puis créez chez votre hébergeur de domaine l'enregistrement CNAME que Vercel indique. Pensez ensuite à mettre cette adresse dans Supabase › URL Configuration.

Évitez d'intégrer l'appli dans une page Webflow (iframe) : certains navigateurs bloquent alors la connexion.

## Reprendre les fiches de la version fichier

Dans l'ancienne version (fichier HTML), cliquez sur « Sauvegarde » : un fichier `.json` est téléchargé. Dans la version en ligne, connecté, cliquez sur « Restaurer » et choisissez ce fichier. Les fiches sont rattachées au compte connecté ; l'administrateur peut ensuite les réattribuer.

## Fichiers

- `public/index.html` : l'application (fonctionne aussi seule, ouverte depuis l'ordinateur, avec les fiches enregistrées dans le navigateur).
- `public/vendor/` : bibliothèque Supabase pour le navigateur (version 2.119.0).
- `api/config.js` : donne au navigateur l'adresse Supabase et la clé publique.
- `api/send-mail.js` : envoi de l'e-mail au client (commercial connecté uniquement).
- `api/admin-users.js` : création de comptes et changement de mot de passe (administrateur uniquement).
- `supabase/schema.sql` : tables, rôles et règles de sécurité.
