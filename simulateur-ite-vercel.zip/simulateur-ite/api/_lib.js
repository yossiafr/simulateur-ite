import { createClient } from "@supabase/supabase-js";

export const env = {
  url: process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  anon: process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
  service: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
};

export const mailConfigure = () => !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);

// Clé de service : uniquement côté serveur.
export function serviceClient() {
  return createClient(env.url, env.service, { auth: { persistSession: false, autoRefreshToken: false } });
}

// Vérifie le jeton envoyé par le navigateur et renvoie le profil actif, sinon null.
export async function appelant(req) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token || !env.url || !env.service) return null;
  const svc = serviceClient();
  const { data: { user } = {}, error } = await svc.auth.getUser(token);
  if (error || !user) return null;
  const { data: profil } = await svc.from("ite_profiles").select("*").eq("id", user.id).maybeSingle();
  if (!profil || !profil.actif) return null;
  return { svc, user, profil };
}

export function json(res, status, body) {
  res.setHeader("Cache-Control", "no-store");
  res.status(status).json(body);
}
