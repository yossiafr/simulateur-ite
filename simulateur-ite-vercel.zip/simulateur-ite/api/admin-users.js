import { appelant, json } from "./_lib.js";

// Gestion des comptes par l'administrateur : création et mot de passe.
// L'activation, la désactivation et le rôle se modifient directement (protégés par la base).
export default async function handler(req, res) {
  if (req.method !== "POST") return json(res, 405, { erreur: "Méthode non autorisée" });
  const qui = await appelant(req);
  if (!qui) return json(res, 401, { erreur: "Session expirée : reconnectez-vous." });
  if (qui.profil.role !== "admin") return json(res, 403, { erreur: "Réservé à l'administrateur." });
  const { svc } = qui;
  const b = req.body || {};

  if (b.action === "create") {
    const email = String(b.email || "").trim().toLowerCase();
    const nom = String(b.nom || "").trim();
    const role = b.role === "admin" ? "admin" : "commercial";
    const password = String(b.password || "");
    if (!email || !nom) return json(res, 400, { erreur: "Renseignez le nom et l'e-mail." });
    if (password.length < 8) return json(res, 400, { erreur: "Le mot de passe doit faire au moins 8 caractères." });
    const { data, error } = await svc.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { nom } });
    if (error) return json(res, 400, { erreur: /already|exists/i.test(error.message) ? "Un compte existe déjà avec cet e-mail." : error.message });
    const { error: e2 } = await svc.from("ite_profiles")
      .upsert({ id: data.user.id, email, nom, role, actif: true });
    if (e2) return json(res, 500, { erreur: "Compte créé mais non activé : " + e2.message });
    return json(res, 200, { ok: true, id: data.user.id });
  }

  if (b.action === "password") {
    if (String(b.password || "").length < 8) return json(res, 400, { erreur: "8 caractères minimum." });
    const { error } = await svc.auth.admin.updateUserById(String(b.id), { password: String(b.password) });
    return error ? json(res, 400, { erreur: error.message }) : json(res, 200, { ok: true });
  }

  json(res, 400, { erreur: "Action inconnue." });
}
