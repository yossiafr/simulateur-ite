import { env, mailConfigure, json } from "./_lib.js";

// Donne au navigateur l'adresse du projet Supabase et la clé publique (anon), qui ne donnent accès à rien sans connexion.
export default function handler(req, res) {
  if (!env.url || !env.anon) return json(res, 503, { erreur: "Supabase n'est pas encore configuré dans Vercel." });
  json(res, 200, { url: env.url, anon: env.anon, mail: mailConfigure() });
}
