import nodemailer from "nodemailer";
import { appelant, mailConfigure, json } from "./_lib.js";

const emailValide = (e) => /^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/.test(e);

// Envoi de la simulation au client, depuis l'adresse SMTP configurée, réponse vers le commercial.
export default async function handler(req, res) {
  if (req.method !== "POST") return json(res, 405, { erreur: "Méthode non autorisée" });
  if (!mailConfigure()) return json(res, 501, { erreur: "Envoi automatique non configuré (variables SMTP dans Vercel)." });
  const qui = await appelant(req);
  if (!qui) return json(res, 401, { erreur: "Session expirée : reconnectez-vous." });
  const { to, subject, html, text, fromName } = req.body || {};
  const dest = String(to || "").trim();
  if (!emailValide(dest)) return json(res, 400, { erreur: "Adresse e-mail du client invalide." });
  if (!html || String(html).length > 200000) return json(res, 400, { erreur: "Message vide ou trop long." });
  const port = +(process.env.SMTP_PORT || 465);
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port, secure: port === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  const adresse = process.env.SMTP_FROM || process.env.SMTP_USER;
  const nom = String(fromName || qui.profil.nom || "").replace(/["<>\r\n]/g, "").trim().slice(0, 80);
  try {
    await transport.sendMail({
      from: nom ? `"${nom}" <${adresse}>` : adresse,
      to: dest,
      replyTo: qui.profil.email,
      subject: String(subject || "Votre simulation").replace(/[\r\n]/g, " ").slice(0, 200),
      html: String(html),
      text: String(text || ""),
    });
    json(res, 200, { ok: true });
  } catch (e) {
    json(res, 502, { erreur: "Le serveur d'envoi a refusé le message : " + (e.message || e) });
  }
}
