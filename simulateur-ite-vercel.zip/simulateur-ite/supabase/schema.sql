-- Simulateur d'autofinancement ITE : schéma Supabase
-- À coller une seule fois dans Supabase > SQL Editor > New query > Run.
-- Les noms commencent par ite_ : le script fonctionne aussi dans un projet Supabase existant.

-- 1. Comptes : commerciaux et administrateurs ---------------------------------
create table if not exists public.ite_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  nom text not null default '',
  role text not null default 'commercial' check (role in ('admin','commercial')),
  actif boolean not null default true,
  created_at timestamptz not null default now()
);

-- Le premier compte devient administrateur actif.
-- Les suivants sont créés désactivés : c'est l'administrateur qui les active (ou les crée depuis l'appli).
-- Une inscription publique laissée ouverte par erreur ne donne donc accès à rien.
create or replace function public.ite_handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare premier boolean := not exists (select 1 from public.ite_profiles where role = 'admin');
begin
  insert into public.ite_profiles (id, email, nom, role, actif)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'nom', ''),
          case when premier then 'admin' else 'commercial' end, premier)
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists ite_on_auth_user_created on auth.users;
create trigger ite_on_auth_user_created after insert on auth.users
  for each row execute function public.ite_handle_new_user();

create or replace function public.ite_is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.ite_profiles where id = auth.uid() and role = 'admin' and actif)
$$;
create or replace function public.ite_is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.ite_profiles where id = auth.uid() and actif)
$$;

-- 2. Réglages par défaut (une seule ligne, modifiable par l'administrateur) ---
create table if not exists public.ite_config (
  id int primary key default 1 check (id = 1),
  data jsonb not null,
  updated_at timestamptz not null default now()
);
insert into public.ite_config (id, data) values (1, '{
  "tauxEco": 25, "taux": 6, "duree": 120, "differe": 6, "tauxPV": 10, "hausse": 0
}') on conflict (id) do nothing;

-- 3. Fiches clients -------------------------------------------------------------
create table if not exists public.ite_clients (
  id text primary key,
  owner uuid not null default auth.uid() references public.ite_profiles(id),
  data jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ite_clients_owner_idx on public.ite_clients(owner);

create or replace function public.ite_touch() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists ite_clients_touch on public.ite_clients;
create trigger ite_clients_touch before update on public.ite_clients
  for each row execute function public.ite_touch();

-- 4. Sécurité (Row Level Security) ---------------------------------------------
-- Commercial : voit et modifie uniquement ses propres clients.
-- Administrateur : voit et modifie tout, réattribue, supprime, gère les comptes et les réglages.
alter table public.ite_profiles enable row level security;
alter table public.ite_config enable row level security;
alter table public.ite_clients enable row level security;

drop policy if exists ite_profiles_read on public.ite_profiles;
create policy ite_profiles_read on public.ite_profiles for select
  using (id = auth.uid() or public.ite_is_admin());
drop policy if exists ite_profiles_admin on public.ite_profiles;
create policy ite_profiles_admin on public.ite_profiles for update
  using (public.ite_is_admin()) with check (public.ite_is_admin());

drop policy if exists ite_config_read on public.ite_config;
create policy ite_config_read on public.ite_config for select using (public.ite_is_member());
drop policy if exists ite_config_admin on public.ite_config;
create policy ite_config_admin on public.ite_config for update
  using (public.ite_is_admin()) with check (public.ite_is_admin());

drop policy if exists ite_clients_read on public.ite_clients;
create policy ite_clients_read on public.ite_clients for select
  using (public.ite_is_member() and (owner = auth.uid() or public.ite_is_admin()));
drop policy if exists ite_clients_insert on public.ite_clients;
create policy ite_clients_insert on public.ite_clients for insert
  with check (public.ite_is_member() and (owner = auth.uid() or public.ite_is_admin()));
drop policy if exists ite_clients_update on public.ite_clients;
create policy ite_clients_update on public.ite_clients for update
  using (public.ite_is_member() and (owner = auth.uid() or public.ite_is_admin()))
  with check (public.ite_is_member() and (owner = auth.uid() or public.ite_is_admin()));
drop policy if exists ite_clients_delete on public.ite_clients;
create policy ite_clients_delete on public.ite_clients for delete using (public.ite_is_admin());

-- Un commercial ne peut pas changer lui-même le propriétaire d'une fiche.
create or replace function public.ite_guard_owner() returns trigger language plpgsql as $$
begin
  if new.owner is distinct from old.owner and not public.ite_is_admin() then
    raise exception 'Seul un administrateur peut réattribuer une fiche';
  end if;
  return new;
end $$;
drop trigger if exists ite_clients_guard on public.ite_clients;
create trigger ite_clients_guard before update on public.ite_clients
  for each row execute function public.ite_guard_owner();

-- Un commercial ne peut pas modifier son propre rôle (la politique d'update est réservée à l'admin).
